============
Installation
============
Launch Kodi >> Add-ons >> Get More >> .. >> Install from zip file

Enjoy!
