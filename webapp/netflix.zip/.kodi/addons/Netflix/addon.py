import subprocess
proc = subprocess.Popen(["brave-browser-stable","--password-store=basic","-kiosk","https://www.netflix.com"])
